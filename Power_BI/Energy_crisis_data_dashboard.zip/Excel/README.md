[Entrance_Admission_test.xlsx](./Entrance_Admission_test.xlsx)  --- This is an entrance admission test project which can be used in both primary and secondary schools
[Mydashboard.xlsx](./Mydashboard.xlsx) --- This contains a dashboard showing the top 3 partners for an anonymous company
